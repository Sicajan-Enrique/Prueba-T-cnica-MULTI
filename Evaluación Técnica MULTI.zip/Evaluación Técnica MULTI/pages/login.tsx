import { useState } from 'react';
import axios from 'axios';
import { Button, TextField } from '@mui/material';

export default function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const response = await axios.post('/api/auth/login', { username, password });
    localStorage.setItem('token', response.data.access_token);
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField label="Username" onChange={e => setUsername(e.target.value)} />
      <TextField label="Password" type="password" onChange={e => setPassword(e.target.value)} />
      <Button type="submit">Login</Button>
    </form>
  );
}
