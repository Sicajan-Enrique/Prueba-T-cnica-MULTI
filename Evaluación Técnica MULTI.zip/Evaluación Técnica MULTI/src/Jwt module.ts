import { Injectable, CanActivate, ExecutionContext } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common';

@Module({
    imports: [
      JwtModule.register({
        secret: 'secretKey', // Usar una variable de entorno
        signOptions: { expiresIn: '1h' },
      }),
    ],
  })
  export class AuthModule {}

  @Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private jwtService: JwtService) {}

  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const token = request.headers.authorization?.split(' ')[1];
    return !!this.jwtService.verify(token);
  }
}

@Injectable()
export class PermissionsGuard implements CanActivate {
  canActivate(context: ExecutionContext): boolean {
    const request = context.switchToHttp().getRequest();
    const user = request.user;
    // Aquí verifica los permisos del usuario para acceder a la ruta
    return user.permissions.includes('create');
  }
}