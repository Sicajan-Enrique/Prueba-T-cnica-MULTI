import { TypeOrmModule } from '@nestjs/typeorm';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'user',
      password: 'password',
      database: 'database',
      entities: [User, Module, Permission], // define las entidades
      synchronize: true, // Sólo para desarrollo
    }),
  ],
})
export class AppModule {}
