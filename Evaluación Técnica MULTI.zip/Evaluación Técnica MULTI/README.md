Buen Día esperando que se encuntre bien 
En el lado del Back-End creo que todo estuvo bien, mas bien fue algo nuevo para mi teniendo una nueva expericnaci pero es un gusto poder aprender con ustedes y serguir desarrollandome en la industria del Desarrollo
Para el lado del Front-End tuve unas difultades pero nada es imposible
back npm run stard 
front npm run dev
